<?php 
class koneksi{
	public function get_koneksi()
	{
		$conn=mysqli_connect("localhost","rdanang","*@*#14m-R00t","uasweb");//cek koneksi
		if(mysqli_connect_error()){
			echo"koneksi gagal : ".mysqli_connect_error();
		}
		return $conn;
	}
}
$konek = new koneksi();
$koneksi=$konek->get_koneksi();
?>